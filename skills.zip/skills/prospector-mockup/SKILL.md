---
name: prospector-mockup
description: Agent 3 of the Prospector pipeline — builds a single-page Romanian demo website (mockup) for a qualified lead in under 60 minutes using the bundled template and sector palette system. Use this skill whenever the user wants to build a mockup, create a demo site for a prospect, produce a propunere de site, or says anything like "build the mockup for", "make the demo site", "fă site-ul demo". Read this file completely before writing any HTML for a prospect.
---

# Prospector — Agent 3: Mockup Builder

## Mission
Produce a mobile-first, single-file demo website that makes the owner say
"acesta este magazinul meu" within five seconds of opening the link on their
phone. Speed and emotional recognition beat feature depth. Budget: ≤ 60
minutes including QA.

## Inputs required (from Agent 2's pipeline row + live Maps listing)

Business name · category · locality · address · phone (mobile, WhatsApp-
capable) · opening hours · 2–3 real review quotes with author first name +
initial · whether photos exist on the listing · services inferred from
category, reviews, and photos. If any of these are missing, fetch them from
the Maps listing before building — do not invent them.

## Build procedure

1. Copy `assets/template.html` to a working file named `{slug}.html`
   (slug = lowercase business name, hyphens, no diacritics).
2. Pick the sector palette from the table below and replace the `:root`
   palette block (the template marks it clearly).
3. Replace every `{{TOKEN}}` in the file. Then verify none remain:
   `grep -o '{{[A-Z_0-9]*}}' {slug}.html` must return nothing.
4. Write the Romanian copy per the copy rules below.
5. Run the QA checklist. Deliver the file and the deployment note.

## Sector palette system

The template's layout, typography, and section order are fixed (they are the
proven pattern). Only the palette variables change per sector:

| Sector | --c-primary | --c-accent | --c-accent-2 | --c-bg | --c-bg-alt | Display font |
|---|---|---|---|---|---|---|
| Agri / feed / food producers | #5C1A1A | #C8860A | #E8A020 | #F5ECD7 | #EDE0C4 | Playfair Display |
| Auto (dezmembrări, service, vulcanizare) | #16181D | #E63B2E | #F2A33C | #F4F4F2 | #E9E9E5 | Oswald |
| Construction / trades / metal | #1F2A33 | #E8A020 | #C8860A | #F2F0EB | #E7E4DC | Oswald |
| Carpentry / furniture | #3B2A1D | #B5762A | #D99A45 | #F6F1E8 | #ECE3D4 | Playfair Display |
| Vet / salon / services | #234A3F | #C8860A | #2D6A4F | #F4F1EA | #E9E4D8 | Playfair Display |

Rules carried over from the proven system: page background is never pure
white; primary colour only on dark sections (header, hero, owner strip,
footer, CTA strip); accent never as a large background; no pure black text
(use the template's `--c-text`); button radius ≤ 6px; no gradients on hero;
no parallax, no heavy JavaScript; hover transitions 0.2s only.

## Copy rules (Romanian)

- Correct diacritics everywhere: ă â î ș ț. Test them in the H1.
- Register: formal `dumneavoastră` in body copy; imperative singular on
  buttons ("Scrie pe WhatsApp", "Cere ofertă").
- Hero H1 = business name. Hero subline = one concrete sentence naming the
  locality and the core service. No slogans, no marketing abstractions.
- Services grid: 4–6 cards, each a real service the business plausibly offers
  based on category and reviews. Plain nouns, one-line descriptions.
- "De ce noi" pillars: exactly 3, grounded in verifiable facts (e.g. "Peste
  {N} recenzii de 5 stele pe Google", "În {locality} — aproape de
  dumneavoastră", "Program {hours}").
- Reviews section: only **real Google reviews**, quoted faithfully, max 3,
  author as "Ion M." Never fabricate or embellish a review.

## Call-to-action design (WhatsApp-first)

This pipeline's outreach channel is WhatsApp/Messenger, not phone — the
mockup's CTAs should match that, since the demo is what a prospect opens
after a text message, not a phone call. WhatsApp is the primary button
everywhere (hero, CTA strip, sticky bottom bar, contact section). A phone
number still appears in the footer/contact block for the visitor's own
convenience (some end-customers will want to call the business), but it is
never the leading action in the design.

## Integrity rules (non-negotiable)

- **Never invent claims**: no fictional founding years, certifications,
  guarantees, client counts, or brand partnerships. Every stated fact must be
  verifiable from the listing or reviews. Where a template section needs a
  fact you do not have, use neutral phrasing or delete the element.
- The demo must be honest about what it is: the template's footer disclaimer
  ("Propunere de website — demonstrație realizată de {{AGENCY_NAME}}") and the
  `noindex,nofollow` meta stay in every mockup. They are removed only after
  the client signs.
- Host under the agency's demo subdomain (e.g. `demo.{agency}.ro/{slug}` or a
  Netlify URL) — never on a domain containing the prospect's name.
- If the lead is marked `LOST` or goes silent 30 days after last contact,
  take the demo offline.

## QA checklist (run every time)

1. `grep '{{'` returns nothing.
2. Renders correctly at 360px width: sticky bottom bar visible, no horizontal
   scroll, tap targets ≥ 44px.
3. `wa.me` link opens the correct number with the prefilled message;
   `tel:` link (secondary, footer only) dials the correct number.
4. Diacritics render in headings and body.
5. Maps embed points at the correct listing; "Traseu" opens directions.
6. All images load; no broken references; page weight sensible (< ~1.5 MB).
7. Footer disclaimer + noindex meta present.

## Output

Deliver `{slug}.html`, state the chosen palette and any facts you could not
verify (and therefore omitted), give the deployment step (drag the file into
Netlify Drop or upload to the demo subdomain), and instruct: update the
pipeline row to `status=BUILT` with the `mockup_url`, then run
prospector-outreach.
